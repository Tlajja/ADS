#include "Cryptarithmetic.h"

const char *test_cases[][3] = {
    {"SEND", "MORE", "MONEY"},
    {"KYOTO", "OSAKA", "TOKYO"},
    {"CRACK", "HACK", "ERROR"},
    {"BASE", "BALL", "GAME"}
};

int main() {
    for (int i = 0; i < sizeof(test_cases) / sizeof(test_cases[0]); i++) {
        run_test(test_cases[i][0], test_cases[i][1], test_cases[i][2]);
    }
    return 0;
}

