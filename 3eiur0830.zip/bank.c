#include "bank.h"
#include "queue.h"

void printUsage(char *programName) {
    printf("Usage: %s [params_file] [-rnd seed]\n", programName);
    printf("Options:\n");
    printf("  params_file : Read parameters from specified file (default: "
           "params.txt)\n");
    printf("  -rnd (seed)   : Set random seed (default: current time)\n");
    printf("  -t       : Run test with default parameters (500 5 50 40 10)\n");
    printf("If no arguments are provided, uses default params\n");
    printf("Input format:\n");
    printf("simulationTime numTellers arrivalProbability maxServiceTime");
}

Params readParams(FILE *input) {
    // Default Stats
    Params params = {500, 5, 50, 10, time(NULL)};
    if (input) {
        fscanf(input, "%d", &params.simulationTime);
        fscanf(input, "%d", &params.numTellers);
        fscanf(input, "%d", &params.arrivalProbability);
        fscanf(input, "%d", &params.maxServiceTime);
    }

    return params;
}

void initTellers(Teller *tellers, int numTellers) {
    for (int i = 0; i < numTellers; i++) {
        tellers[i].isBusy = 0;
        tellers[i].remainingTime = 0;
        tellers[i].customersServed = 0;
        tellers[i].totalServiceTime = 0;
    }
}

void simulateBank(Params params) {
    Queue *queue = create();
    Teller tellers[params.numTellers];
    Stats stats = {0, 0, 0, 0, 0};

    initTellers(tellers, params.numTellers);
    srand(params.randomSeed);

    // Customer arrival
    for (int minute = 0; minute < params.simulationTime; minute++) {
        // Customer arrival
        if (rand() % 100 < params.arrivalProbability) {
            enqueue(queue, minute);
            stats.totalCustomers++;

            if (count(queue) > stats.maxQueueSize)
                stats.maxQueueSize = count(queue);
        }

        // Processing tellers
        for (int i = 0; i < params.numTellers; i++) {
            if (tellers[i].isBusy) {
                tellers[i].remainingTime--;
                if (tellers[i].remainingTime == 0) {
                    tellers[i].isBusy = 0;
                }
                continue;
            }

            // Assign customer if available
            if (!isEmpty(queue)) {
                bool status;
                int readyTime = dequeue(queue, &status);
                if (minute >= readyTime) { // Customer is ready
                    int waitTime = minute - readyTime;
                    stats.totalWaitingTime += waitTime;
                    stats.customersWithWait++;
                    if (waitTime > stats.maxWaitingTime) {
                        stats.maxWaitingTime = waitTime;
                    }

                    int serviceTime = rand() % params.maxServiceTime + 1;
                    tellers[i].isBusy = true;
                    tellers[i].remainingTime = serviceTime;
                    tellers[i].customersServed++;
                    tellers[i].totalServiceTime += serviceTime;
                } else {
                    enqueue(queue, readyTime); // Not ready yet
                }
            }
        }
    }

    // Print parameters uses
    printf("Parameters:\n");
    printf("Simulation time: %d\n", params.simulationTime);
    printf("Number of tellers: %d\n", params.numTellers);
    printf("Arrival probability: %d%%\n", params.arrivalProbability);
    printf("Max service time: %d\n", params.maxServiceTime);

    // Calculate and print results
    printf("\nSimulation Results:\n");
    printf("- Total customers: %d\n", stats.totalCustomers);
    printf("- Customers served per teller:");
    for (int i = 0; i < params.numTellers; i++) {
        printf(" %d", tellers[i].customersServed);
    }
    printf("\n- Average waiting time: %.2f\n",
           stats.customersWithWait
               ? (float)stats.totalWaitingTime / stats.customersWithWait
               : 0);
    printf("- Maximum waiting time: %d\n", stats.maxWaitingTime);
    printf("- Maximum queue size: %d\n", stats.maxQueueSize);

    // Calculate teller utilization
    printf("- Teller utilization:\n");
    for (int i = 0; i < params.numTellers; i++) {
        float utilization =
            (float)tellers[i].totalServiceTime / params.simulationTime * 100;
        printf("  Teller %d: %.1f%%\n", i + 1, utilization);
    }

    done(queue);
}
